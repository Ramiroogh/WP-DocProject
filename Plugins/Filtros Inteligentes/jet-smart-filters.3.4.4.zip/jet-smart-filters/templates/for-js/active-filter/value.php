<?php
/**
 * Active filter value template
 */

?>
<div class="jet-active-filter__val">/% $value %/</div>